
// This file should re-export from the hooks directory
import { useToast, toast } from "@/components/ui/toast";

export { useToast, toast };
