import {
    fetchAllStudyPlans,
    createStudyPlan,
    updateStudyPlanById,
    deleteStudyPlanById
  } from '@/lib/services/studies';
  